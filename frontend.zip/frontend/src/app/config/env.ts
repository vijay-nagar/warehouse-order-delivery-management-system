export const env = {
  apiBaseUrl:
    import.meta.env.VITE_API_BASE_URL ??
    "http://localhost:3001",
} as const;
